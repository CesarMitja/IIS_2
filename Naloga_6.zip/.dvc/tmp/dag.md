```mermaid
flowchart TD
	node1["data\processed\data_for_prediction.csv.dvc"]
	node2["data\processed\test.csv.dvc"]
	node3["data\processed\train.csv.dvc"]
	node4["data\raw\kolesa.csv.dvc"]
	node5["data\raw\vreme.csv.dvc"]
```